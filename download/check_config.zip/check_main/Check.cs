﻿using BNCS;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Xml.Schema;

namespace check_main
{
    public class Check
    {
        private string _configPath;
        List<string> _errors = new List<string>();
        List<string> _duplicateInstances = new List<string>();

        Dictionary<string, ConfigInstance> _dicInstances = new Dictionary<string, ConfigInstance>();

        public event EventHandler<string> OnError;
        public event EventHandler<string> OnInfo;

        public void FireError(string error)
        {
            var e = OnError;
            if (e != null)
            {
                e(this, error);
            }
        }

        public void FireInfo(string info)
        {
            var e = OnInfo;
            if (e != null)
            {
                e(this, info);
            }
        }

        public void Init()
        {
            AddInfo("Initialisation", "Starting check_config ...");

            if(VerifyEnvironment())
            {
                _configPath = BNCSFilePaths.BNCSFilePathsFactory().ConfigPath;
                LoadInstances();

                //Load Workstations

                //Load Users

                //Load Applications

                //Load Panelsets - depends on Applications

                //Load Launch - depends on Workstations

            }
        }

        public void AddError(string config_section, string message)
        {
            string error = string.Format("{0} - {1}", config_section, message);
            Debug.WriteLine("config_check " + error);
            _errors.Add(error);
            FireError(error);
        }

        public void AddInfo(string config_section, string message)
        {
            string info = string.Format("{0} - {1}", config_section, message);
            Debug.WriteLine("config_check " + info);
            FireInfo(info);
        }

        private bool VerifyEnvironment()
        {
            bool valid = true;

            //Check that we have all system environment variables
            string sysRoot = Environment.GetEnvironmentVariable("CC_ROOT", EnvironmentVariableTarget.Machine);
            string sysSystem = Environment.GetEnvironmentVariable("CC_SYSTEM", EnvironmentVariableTarget.Machine);
            string sysWorkstation = Environment.GetEnvironmentVariable("CC_WORKSTATION", EnvironmentVariableTarget.Machine);

            if (sysRoot == null)
            {
                valid = false;
                AddError("Env Vars", "CC_ROOT not defined in System Environment Variables");
            }
            else
            {
                AddInfo("Env Vars", "CC_ROOT=" + sysRoot);
            }

            if (sysSystem == null)
            {
                valid = false;
                AddError("Env Vars", "CC_SYSTEM not defined in System Environment Variables");
            }
            else
            {
                AddInfo("Env Vars", "CC_SYSTEM=" + sysSystem);
            }

            if (sysWorkstation == null)
            {
                valid = false;
                AddError("Env Vars", "CC_WORKSTATION not defined in System Environment Variables");
            }


            //Check that we have no user environment variables
            string usrRoot = Environment.GetEnvironmentVariable("CC_ROOT", EnvironmentVariableTarget.User);
            string usrSystem = Environment.GetEnvironmentVariable("CC_SYSTEM", EnvironmentVariableTarget.User);
            string usrWorkstation = Environment.GetEnvironmentVariable("CC_WORKSTATION", EnvironmentVariableTarget.User);

            if (usrRoot != null)
            {
                valid = false;
                AddError("Env Vars", "CC_ROOT has been defined in User Environment Variables");
            }

            if (usrSystem != null)
            {
                valid = false;
                AddError("Env Vars", "CC_SYSTEM has been defined in User Environment Variables");
            }

            if (usrWorkstation != null)
            {
                valid = false;
                AddError("Env Vars", "CC_WORKSTATION has been defined in User Environment Variables");
            }

            return valid;
        }

        private void LoadInstances()
        {
            string fileName = "instances.xml";
            FireInfo("Checking " + fileName);
            Debug.WriteLine("config_check LoadInstances() configPath=" + _configPath);
            string fileInstances = Path.Combine(_configPath, fileName);

            XDocument docInstances = null;

            try
            {
                docInstances = XDocument.Load(fileInstances, LoadOptions.None);
            }
            catch (FileNotFoundException efnf)
            {
                AddError("Instances", efnf.Message);
            }
            catch(System.Xml.XmlException exml)
            {
                AddError("Instances", exml.Message);
            }

            if(docInstances != null)
            {

                //Check schema is valid
                XmlSchemaSet schemas = new XmlSchemaSet();
                string schemaNamespace = "";
                string schemaFileName = Path.Combine(_configPath, "instances.xsd");
                schemas.Add(schemaNamespace, schemaFileName);

                string msg = "";
                docInstances.Validate(schemas, (o, e) =>
                {
                    if (e.Message == "The required attribute 'ref' is missing.")
                    {
                        var inst = (XElement)o;
                        if(inst != null)
                        {
                            if(inst.Attribute("composite") != null)
                            {
                                if(inst.Attribute("composite").Value == "yes")
                                {
                                    //For a composite instance the ref attribute is not required
                                }
                                else
                                {
                                    msg += "\t" + o.ToString() + Environment.NewLine;
                                }
                            }
                        }
                    }
                    else
                    {
                        msg += e.Message + Environment.NewLine;
                        msg += o.ToString() + Environment.NewLine;
                    }
                });
                Console.WriteLine(msg == "" ? "Document is valid" : "Document invalid: " + msg);

                //Check #1 Root.Name == "instances"
                Debug.WriteLine("config_check LoadInstances() docInstances.Root.Name=" + docInstances.Root.Name);

                /*
                IEnumerable<string> idList = from instancesTest in docInstances.Root.Descendants()
                    let inst = instancesTest
                    where inst.Name == "instance"
                    orderby inst.Attribute("id").Value
                    select inst.Name + " id=" + inst.Attribute("id").Value;

                foreach (string id in idList)
                    Console.WriteLine(id);
                */

                //Check #2 Has Children with Name == "instance"
                IEnumerable<XElement> instances = docInstances.Root.Elements();

                // Read the entire XML
                foreach (var instance in instances)
                {
                    //Check #2 Has Children with Name == "instance"
                    if (instance.Name == "instance")
                    {
                        var attlist = instance.Attributes();
                        
                        //At this point an xsd check may be more productive
                        
                        //Check #3 instance element has attribute 'id'
                        //bool hasID = true;
                        string id = "";
                        if (instance.Attribute("id") != null)
                        {
                            id = instance.Attribute("id").Value;
                            Debug.WriteLine(string.Format("instance id: {0}", id));
                            ConfigInstance existingInstance;
                            if (_dicInstances.TryGetValue(id, out existingInstance))
                            {
                                //TODO - show the line of the original and the duplicate
                                AddError("Instances", string.Format("An instance with id=\"{0}\" already exists", id));
                                _duplicateInstances.Add(instance.ToString());
                            }
                            else
                            {
                                ConfigInstance newInstance = new ConfigInstance(id, instance);
                                _dicInstances.Add(id, newInstance);
                            }
                        }
                        else
                        {
                            //hasID = false;
                            AddError("Instances", string.Format("Instance missing required attribute 'id': \n\t{0}\n", instance.ToString()));
                        }
                        
                        /*
                        if(hasID)
                        {

                        }*/
                    }
                    else
                    {
                        AddError("Instances", "Child Element Name must be instance - found " + instance.Name);
                    }

                }
                //Debug.WriteLine("config_check LoadInstances() docInstances.Root.Name=" + docInstances.Root.Name);

                //Array of instances now available

                foreach (var instance in _dicInstances.Values)
                {
                    //Check #4 instance composite is valid
                    //  <instance id="mc_rtr_sdi_infrastructure" type="router_sdi" composite="no" ref="device=1,offset=0" alt_id="MC Infrastructure"/>
                    if (instance.IsComposite)
                    {
                        //AddInfo("Instances", string.Format("Found composite with id=\"{0}\"", instance.Id));

                        foreach (var pair in instance.GroupErrors)
                        {
                            AddError("Instances", string.Format("group id=\"{0}\" {1}", pair.Key, pair.Value));
                        }

                        foreach (var pair in instance.Groups)
                        {
                            string groupID = pair.Key;
                            string groupInstanceID = pair.Value;
                            //AddInfo("Instances", string.Format("\tgroup id=\"{0}\" instance=\"{1}\"", pair.Key, groupInstanceID));

                            if(groupInstanceID.Length == 0)
                            {
                                AddInfo("Instances", string.Format("Composite:\"{0}\" Group:\"{1}\" - has empty instance", instance.Id, groupID));
                            }
                            else
                            {
                                //Find instance referred to in group
                                ConfigInstance groupInstance;
                                if (_dicInstances.TryGetValue(groupInstanceID, out groupInstance))
                                {
                                    //AddInfo("Instances", string.Format("\t\tFound id=\"{0}\"", groupInstance.Id));
                                }
                                else
                                {
                                    AddError("Instances", string.Format("Composite:\"{0}\" Group:\"{1}\" - did not find instance with id=\"{2}\"",
                                        instance.Id, groupID, groupInstanceID));
                                }
                            }
                        }
                        
                        //AddInfo("Instances", string.Format("Found composite with id=\"{0}\"", instance.Id));
                    }
                }
            }
        }
    }
}
