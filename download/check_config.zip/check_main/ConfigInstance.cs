﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace check_main
{
    class ConfigInstance
    {
        private string _id = "";
        private XElement _xmlElement = null;
        private bool _isComposite = false;

        private Dictionary<string, string> _groups = new Dictionary<string, string>();
        private Dictionary<string, string> _groupErrors = new Dictionary<string, string>();

        public string Id
        {
            get { return _id; }
        }

        public bool IsComposite
        {
            get { return _isComposite; }
        }

        public Dictionary<string,string> Groups
        {
            get { return _groups; }
        }

        public Dictionary<string, string> GroupErrors
        {
            get { return _groupErrors; }
        }

        public ConfigInstance(string id, XElement element)
        {
            _id = id;
            _xmlElement = element;

            initInstance();
        }

        private void initInstance()
        {
            if(_xmlElement.Attribute("composite") != null)
            {
                if(_xmlElement.Attribute("composite").Value == "yes")
                {
                    _isComposite = true;

                    int groups = 0;

                    foreach(var group in _xmlElement.Descendants("group"))
                    {
                        groups++;
                        
                        //Check if the group has 
                        if(group.Attribute("id") != null)
                        {
                            string id = group.Attribute("id").Value;
                        
                            if(group.Attribute("instance") != null)
                            {
                                string instance = group.Attribute("instance").Value;
                                Debug.WriteLine("\tid=" + id + " instance=" + instance);

                                _groups.Add(id, instance);
                            }
                            else
                            {
                                //Group has no instance attribute
                                string error = string.Format("Missing required attribute: 'instance'\n\t- raw element: {0}", group.ToString()); 
                                _groupErrors.Add(id, error);
                            }
                        }
                    }
                }
            }
        }
    }
}
