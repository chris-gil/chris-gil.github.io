﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace check_config
{
    class Program
    {
        static void Main(string[] args)
        {
            check_main.Check c = new check_main.Check();

            //c.OnEvent += u_OnEvent;
            c.OnError += c_OnError;
            c.OnInfo += c_OnInfo;

            c.Init();

            //var k = Console.ReadKey();
        }

        static void c_OnInfo(object sender, string e)
        {
            string message = string.Format("Info: {0}", e);
            Console.WriteLine(message);
        }

        static void c_OnError(object sender, string e)
        {
            string message = string.Format("Error: {0}", e);
            Console.WriteLine(message);
        }
    }
}
